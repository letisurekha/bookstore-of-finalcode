import {
   AUTHOR_LIST_REQUEST,
   AUTHOR_LIST_SUCCESS,
   AUTHOR_LIST_FAIL,
   AUTHOR_DETAILS_REQUEST,
   AUTHOR_DETAILS_SUCCESS,
   AUTHOR_DETAILS_FAIL,
   AUTHOR_SAVE_REQUEST,
   AUTHOR_SAVE_SUCCESS,
   AUTHOR_SAVE_FAIL,
   AUTHOR_DELETE_SUCCESS,
   AUTHOR_DELETE_FAIL,
   AUTHOR_DELETE_REQUEST,
  } from '../constants/authorConstants';
  import axios from 'axios';
  import Axios from 'axios';
  
  const listAuthors = (
    category = '',
    searchKeyword = '',
    sortOrder = ''
  ) => async (dispatch) => {
    try {
      dispatch({ type: AUTHOR_LIST_REQUEST });
      const { data } = await axios.get(
        '/api/authors?author=' +
          category +
          '&searchKeyword=' +
          searchKeyword +
          '&sortOrder=' +
          sortOrder
      );
      dispatch({ type: AUTHOR_LIST_SUCCESS, payload: data });
    } catch (error) {
      dispatch({ type: AUTHOR_LIST_FAIL, payload: error.message });
    }
  };
  
  const saveAuthor = (author) => async (dispatch, getState) => {
    try {
      dispatch({ type: AUTHOR_SAVE_REQUEST, payload: author });
      const {
        userSignin: { userInfo },
      } = getState();
      if (!author._id) {
        const { data } = await Axios.post('/api/authors/author/create', author, {
          headers: {
            Authorization: 'Bearer ' + userInfo.token,
          },
        });
        dispatch({ type: AUTHOR_SAVE_SUCCESS, payload: data });
      } else {
        const { data } = await Axios.put(
          '/api/authors/' + author._id,
          author,
          {
            headers: {
              Authorization: 'Bearer ' + userInfo.token,
            },
          }
        );
        dispatch({ type: AUTHOR_SAVE_SUCCESS, payload: data });
      }
    } catch (error) {
      dispatch({ type: AUTHOR_SAVE_FAIL, payload: error.message });
    }
  };
  
  const detailsAuthor = (authorId) => async (dispatch) => {
    try {
      dispatch({ type: AUTHOR_DETAILS_REQUEST, payload: authorId });
      const { data } = await axios.get('/api/authors/author' + authorId);
      dispatch({ type: AUTHOR_DETAILS_SUCCESS, payload: data });
    } catch (error) {
      dispatch({ type: AUTHOR_DETAILS_FAIL, payload: error.message });
    }
  };
  
  const deleteAuthor = (authorId) => async (dispatch, getState) => {
    try {
      const {
        userSignin: { userInfo },
      } = getState();
      dispatch({ type: AUTHOR_DELETE_REQUEST, payload: authorId });
      const { data } = await axios.delete('/api/authors/' + authorId, {
        headers: {
          Authorization: 'Bearer ' + userInfo.token,
        },
      });
      dispatch({ type: AUTHOR_DELETE_SUCCESS, payload: data, success: true });
    } catch (error) {
      dispatch({ type: AUTHOR_DELETE_FAIL, payload: error.message });
    }
  };
  
 
  
  export {
    listAuthors,
    detailsAuthor,
    saveAuthor,
    deleteAuthor,
  };
  