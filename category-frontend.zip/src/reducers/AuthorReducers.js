import {
    AUTHOR_LIST_REQUEST,
    AUTHOR_LIST_SUCCESS,
    AUTHOR_LIST_FAIL,
    AUTHOR_DETAILS_REQUEST,
    AUTHOR_DETAILS_SUCCESS,
    AUTHOR_DETAILS_FAIL,
    AUTHOR_SAVE_REQUEST,
    AUTHOR_SAVE_SUCCESS,
    AUTHOR_SAVE_FAIL,
    AUTHOR_DELETE_REQUEST,
    AUTHOR_DELETE_SUCCESS,
    AUTHOR_DELETE_FAIL,
  
  } from '../constants/authorConstants';
  
  function authorListReducer(state = { authors: [] }, action) {
    switch (action.type) {
      case AUTHOR_LIST_REQUEST:
        return { loading: true, authors: [] };
      case AUTHOR_LIST_SUCCESS:
        return { loading: false, authors: action.payload };
      case AUTHOR_LIST_FAIL:
        return { loading: false, error: action.payload };
      default:
        return state;
    }
  }
  
  function authorDetailsReducer(state = { author: { reviews: [] } }, action) {
    switch (action.type) {
      case AUTHOR_DETAILS_REQUEST:
        return { loading: true };
      case AUTHOR_DETAILS_SUCCESS:
        return { loading: false, author: action.payload };
      case AUTHOR_DETAILS_FAIL:
        return { loading: false, error: action.payload };
      default:
        return state;
    }
  }
  
  function authorDeleteReducer(state = { author: {} }, action) {
    switch (action.type) {
      case AUTHOR_DELETE_REQUEST:
        return { loading: true };
      case AUTHOR_DELETE_SUCCESS:
        return { loading: false, author: action.payload, success: true };
      case AUTHOR_DELETE_FAIL:
        return { loading: false, error: action.payload };
      default:
        return state;
    }
  }
  
  function authorSaveReducer(state = { author: {} }, action) {
    switch (action.type) {
      case AUTHOR_SAVE_REQUEST:
        return { loading: true };
      case AUTHOR_SAVE_SUCCESS:
        return { loading: false, success: true, author: action.payload };
      case AUTHOR_SAVE_FAIL:
        return { loading: false, error: action.payload };
      default:
        return state;
    }
  }

  export {
    authorListReducer,
    authorDetailsReducer,
    authorSaveReducer,
    authorDeleteReducer,
  };
  