import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import ProfileScreen from './ProfileScreen'


const Admin = () => {
   return <Fragment>
       <div className="card">
           <div className="card-body text-white ">
               <Link to="/orders">Orders</Link>
           </div>
       </div>
       <div className="card">
           <div className="card-body text-white">
           <Link to="/products">Products</Link>
           </div>
       </div>
       <div className="card">
           <div className="card-body">
           <Link to="/categories" className="text-white">Categories</Link>
           </div>
       </div>
       <div className="card">
           <div className="card-body">
           <Link to="/authors" className="text-white">Authors</Link>
           </div>
       </div>
        
        
       </Fragment>
}

export default Admin