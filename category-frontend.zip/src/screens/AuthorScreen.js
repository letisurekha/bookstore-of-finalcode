import React, { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  saveAuthor,
  listAuthors,
  deleteAuthor,
} from '../actions/authorActions';

function AuthorScreen(props) {
  const [modalVisible, setModalVisible] = useState(false);
  const [id, setId] = useState('');
  const [name, setName] = useState('');
 
  const authorList = useSelector((state) => state.authorList);
  const { loading, authors, error } = authorList;

  const authorSave = useSelector((state) => state.authorSave);
  const {
    loading: loadingSave,
    success: successSave,
    error: errorSave,
  } = authorSave;

  const authorDelete = useSelector((state) => state.authorDelete);
  const {
    loading: loadingDelete,
    success: successDelete,
    error: errorDelete,
  } = authorDelete;
  const dispatch = useDispatch();

  useEffect(() => {
    if (successSave) {
      setModalVisible(false);
    }
    dispatch(listAuthors());
    return () => {
      //
    };
  }, [successSave, successDelete]);

  const openModal = (author) => {
    setModalVisible(true);
    setId(author._id);
    setName(author.name);
  };
  const submitHandler = (e) => {
    e.preventDefault();
    dispatch(
      saveAuthor({
        _id: id,
        name
      })
    );
  };
  const deleteHandler = (author) => {
    dispatch(deleteAuthor(author._id));
  };
  return (
    <div className="content content-margined">
           <Link to="/admin">Back to Admin</Link> 
      <div className="product-header">
        <h3>Authors</h3>
        <button className="button primary" onClick={() => openModal({})}>
          Create Author
        </button>
      </div>
      {modalVisible && (
        <div className="form">
          <form onSubmit={submitHandler}>
            <ul className="form-container">
              <li>
                <h2>Create Author</h2>
              </li>
              <li>
                {loadingSave && <div>Loading...</div>}
                {errorSave && <div>{errorSave}</div>}
              </li>

              <li>
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  name="name"
                  value={name}
                  id="name"
                  onChange={(e) => setName(e.target.value)}
                ></input>
              </li>
             
              <li>
                <button type="submit" className="button primary">
                  {id ? 'Update' : 'Create'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setModalVisible(false)}
                  className="button secondary"
                >
                  Back
                </button>
              </li>
            </ul>
          </form>
        </div>
      )}

      <div className="product-list">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          {authors.map((author) => (
              <tr key={author._id}>
                <td>{author._id}</td>
                <td>{author.name}</td>
                <td>
                  <button className="button" onClick={() => openModal(author)}>
                    Edit
                  </button>{' '}
                  <button
                    className="button"
                    onClick={() => deleteHandler(author)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default AuthorScreen;



























/**
 import React, { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  saveCategory,
  listCategories,
  deleteCategory,
} from '../actions/categoryActions';

function CategoryScreen(props) {
  const [modalVisible, setModalVisible] = useState(false);
  const [id, setId] = useState('');
  const [name, setName] = useState('');
 
  const productList = useSelector((state) => state.productList);
  const { loading, products, error } = productList;

  const productSave = useSelector((state) => state.productSave);
  const {
    loading: loadingSave,
    success: successSave,
    error: errorSave,
  } = productSave;

  const productDelete = useSelector((state) => state.productDelete);
  const {
    loading: loadingDelete,
    success: successDelete,
    error: errorDelete,
  } = productDelete;
  const dispatch = useDispatch();

  useEffect(() => {
    if (successSave) {
      setModalVisible(false);
    }
    dispatch(listCategories());
    return () => {
      //
    };
  }, [successSave, successDelete]);

  const openModal = (product) => {
    setModalVisible(true);
    setId(product._id);
    setName(product.name);
  };
  const submitHandler = (e) => {
    e.preventDefault();
    dispatch(
      saveCategory({
        _id: id,
        name
      })
    );
  };
  const deleteHandler = (product) => {
    dispatch(deleteCategory(product._id));
  };
  return (
    <div className="content content-margined">
           <Link to="/admin">Back to Admin</Link> 
      <div className="product-header">
        <h3>Categories</h3>
        <button className="button primary" onClick={() => openModal({})}>
          Create Category
        </button>
      </div>
      {modalVisible && (
        <div className="form">
          <form onSubmit={submitHandler}>
            <ul className="form-container">
              <li>
                <h2>Create Category</h2>
              </li>
              <li>
                {loadingSave && <div>Loading...</div>}
                {errorSave && <div>{errorSave}</div>}
              </li>

              <li>
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  name="name"
                  value={name}
                  id="name"
                  onChange={(e) => setName(e.target.value)}
                ></input>
              </li>
             
              <li>
                <button type="submit" className="button primary">
                  {id ? 'Update' : 'Create'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setModalVisible(false)}
                  className="button secondary"
                >
                  Back
                </button>
              </li>
            </ul>
          </form>
        </div>
      )}

      <div className="product-list">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product._id}>
                <td>{product._id}</td>
                <td>{product.name}</td>
                <td>
                  <button className="button" onClick={() => openModal(product)}>
                    Edit
                  </button>{' '}
                  <button
                    className="button"
                    onClick={() => deleteHandler(product)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default CategoryScreen;

 */
