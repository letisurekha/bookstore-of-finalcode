import React, { useState } from "react";

const Checkbox = ({ categories, handleFilters }) => {
    const [checked, setCheked] = useState([]);

    const handleToggle = categories => () => {
        // return the first index or -1
        const currentCategoryId = checked.indexOf(categories);
        const newCheckedCategoryId = [...checked];
        // if currently checked was not already in checked state > push
        // else pull/take off
        if (currentCategoryId === -1) {
            newCheckedCategoryId.push(categories);
        } else {
            newCheckedCategoryId.splice(currentCategoryId, 1);
        }
        // console.log(newCheckedCategoryId);
        setCheked(newCheckedCategoryId);
        handleFilters(newCheckedCategoryId);
    };

    return   <li className="list-unstyled">
                <input
                    onChange={handleToggle(categories._id)}
                    // value="5f781ad4a636e9403052dc0c"
                    value={checked.indexOf(categories._id === -1)}
                    type="checkbox"
                    className="form-check-input"
                />
                <label className="form-check-label">Frontend</label>
            </li>
            
   
};

export default Checkbox;
