import React, { Fragment } from "react";
import { Link, withRouter } from "react-router-dom";
import { signout, isAuthenticated } from "../auth";
import { itemTotal } from "./cartHelpers";



const Menu = ({history}) => (
    <div>
            <ul className="nav nav-tabs text:white" style={{backgroundColor:"black",height:80,alignContent:"center",marginBottom:10}}>
                <li className="nav-item">
                    <Link
                        className="nav-link"
                        style={{color:"white",fontWeight:"bolder",color:"white",fontSize:25,marginTop:-9}}
                        to="/"
                    >
                <i className="fas fa-book-open">UNICORN</i>
                    </Link>
                </li>
                {isAuthenticated() && (
                        <li className="nav-item">
                            <Link
                                className="nav-link"
                            
                                style={{color:"white"}}
                                to="/cart"
                            > Cart <i className="fas fa-shopping-cart"></i>{" "}
                            <sup>
                                <small className="cart-badge">{itemTotal()}</small>
                            </sup>
                            </Link>
                        </li>
                )}

                {isAuthenticated() && isAuthenticated().user.role === 0 && (
                    <li className="nav-item">
                        <Link
                            className="nav-link"
                            style={{color:"white"}}
                            to="/user/dashboard"
                        >
                            Dashboard
                        </Link>
                    </li>
                )}

                {isAuthenticated() && isAuthenticated().user.role === 1 && (
                    <li className="nav-item">
                        <Link
                            className="nav-link"
                        
                            style={{color:"white"}}
                            to="/admin/dashboard"
                        >
                            Dashboard
                        </Link>
                    </li>
                )}

                {!isAuthenticated() && (
                    <Fragment>
                        <li className="nav-item">
                            <Link
                                className="nav-link"
                            
                                style={{color:"white"}}
                                to="/signin"
                            >
                                Cart
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link
                                className="nav-link"
                            
                                style={{color:"white"}}
                                to="/signin"
                            >
                                Signin
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link
                                className="nav-link"
                            
                                style={{color:"white"}}
                                to="/signup"
                            >
                                Signup
                            </Link>
                        </li>
                    </Fragment>
                )}

                {isAuthenticated() && (
                    <li className="nav-item">
                        <span
                            className="nav-link"
                            style={{ cursor: "pointer", color: "#ffffff" }}
                            onClick={() =>
                                signout(() => {
                                    history.push("/");
                                })
                            }
                        >
                            Signout
                        </span>
                    </li>
                )}
                <li className="nav-item">
                            <Link
                                className="nav-link"
                            
                                style={{color:"white"}}
                                to="/contact"
                            >
                                Contact
                            </Link>
                    </li>
                
            </ul><br/>
        </div>
);

export default withRouter(Menu);

















































































































































































