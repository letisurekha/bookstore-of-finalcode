const Author = require('../models/author');

exports.create = (req, res) =>{
    const author = new Author(req.body);
    author.save((error, data)=>{
        if(error){
            return res.status(400).json({
                error:"Author is not created please try after sometime"
            });
        }
        res.json({data});
    })
};


exports.authorById = (req, res, next, id) =>{
    Author.findById(id).exec((error, author) =>{
        if(error){
            return res.status(400).json({
                error:"Author not found"
            });
        }
        req.author = author
        next();
    });
};




exports.read = (req, res) => {
   return res.json(req.author);
}


exports.remove = (req, res) => {
    let author = req.author;
    author.remove((error, deleteAuthorData) =>{
        if(error){
            return res.status(400).json({
                error:"unable to deleting author"
            });
        }
        res.json({
          //  deleteAuthorData,
            "message":"Author deleted Successfully"
        })
    })
}


exports.update = (req, res) =>{
    const author = req.author
    author.name = req.body.name
    author.save((error, data)=>{
        if(error){
            return res.status(400).json({
                error:"Author is not found to update"
            });
        }
        res.json({data});
    })
};

exports.list =(req, res)=>{
    Author.find().exec((error, author) =>{

        if(error){
            return res.status(400).json({
                error:"Authors are not available"
            });
        }
        res.json({author});
    });
};