import React, { useState, useEffect } from "react";
import Layout from "../core/Layout";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";
import { getProducts, deleteProduct } from "./apiAdmin";

const ManageProducts = () => {
    const [products, setProducts] = useState([]);

    const { user, token } = isAuthenticated();

    const loadProducts = () => {
        getProducts().then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    setProducts(data);
                }
            }
        });
    };

    var x=0;

    const destroy = productId => {
        deleteProduct(productId, user._id, token).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    loadProducts();
                }
            }
        });
    };

    useEffect(() => {
        loadProducts();
    }, []);

    return (
        <Layout
            title="Manage Products"
            description="Perform CRUD on products"
            className="container-fluid mb-5"
        >
            <div className="row">
                <div className="col-12"><hr/>
                    <h2 className="text-center">
                        Total {products.length} products
                    </h2>
                </div>
            </div><br/>
            <div className="product-list">
                <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Action</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {products.map((p,i) => (
                    <tr key={i}>
                        <td>{x=x+1}</td>
                        <td>{p.name}</td>
                        <td>
                               <Link to={`/admin/product/update/${p._id}`}>
                                    <span className="badge badge-warning badge-pill">
                                        Update
                                    </span>
                                </Link>
                        </td>
                        <td>        
                                <span
                                    style={{ cursor: "pointer", color: "#ffffff" }}
                                    onClick={() => destroy(p._id)}
                                    className="badge badge-danger badge-pill"
                                >
                                    Delete
                                </span>
                        </td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>    
        </Layout>
    );
};

export default ManageProducts;
