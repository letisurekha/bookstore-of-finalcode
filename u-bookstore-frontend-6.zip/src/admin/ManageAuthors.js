import React, { useState, useEffect } from "react";
import Layout from "../core/Layout";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";
import { getAuthors, deleteAuthor } from "./apiAdmin";

const ManageAuthors = () => {
    const [authors, setAuthors] = useState([]);

    const { user, token } = isAuthenticated();

    const loadAuthors = () => {
        getAuthors().then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    setAuthors(data);
                }
            }
        });
    };

    var x=0;

    const destroy = authorId => {
        deleteAuthor(authorId, user._id, token).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    loadAuthors();
                }
            }
        });
    };

    useEffect(() => {
        loadAuthors();
    }, []);

    return (
        <Layout
            title="Manage authors"
            description="Perform CRUD on authors"
            className="container-fluid mb-5"
        >
            <div className="row">
                <div className="col-12"><hr/>
                    <h2 className="text-center">
                        Total {authors.length} authors
                    </h2>
                </div>
            </div><br/>
            <div className="product-list">
                <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Action</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {authors && authors.author &&
                        authors.author.map((a,i) => (
                    <tr key={i}>
                        <td>{x=x+1}</td>
                        <td>{a.name}</td>
                        <td>
                               <Link to={`/admin/author/update/${a._id}`}>
                                    <span className="badge badge-warning badge-pill">
                                        Update
                                    </span>
                                </Link>
                        </td>
                        <td>        
                                <span
                                    style={{ cursor: "pointer", color: "#ffffff" }}
                                    onClick={() => destroy(a._id)}
                                    className="badge badge-danger badge-pill"
                                >
                                    Delete
                                </span>
                        </td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>    
        </Layout>
    );
};

export default ManageAuthors;
