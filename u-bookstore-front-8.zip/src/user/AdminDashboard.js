import React from "react";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";

const AdminDashboard = () => {
    const {
        user: { _id, name, email, role }
    } = isAuthenticated();

    const adminLinks = () => {
        return (
            <div className="card">
                 
                <ul className="list-group" style={{textAlign:"center"}}>
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white" to="/create/category">
                            Create Category
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white" to="/create/author">
                            Create Author
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white" to="/create/product">
                            Create Product
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white" to="/admin/orders">
                            View Orders
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white" to="/admin/products">
                            Manage Products
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link" to="/admin/authors">
                            Manage Author
                        </Link>
                    </li> {/*
                    <li className="list-group-item">
                        <Link className="nav-link" to="/admin/categories">
                            Manage categories
                        </Link>
                    </li> */}
                    <li className="list-group-item">
                        <Link className="nav-link btn btn-primary text:white " to={`/profile/${_id}`}>
                            Update Profile
                        </Link>
                    </li>
                </ul>
            </div>
        );
    };

    const adminInfo = () => {
        return (
            <div className="card mb-5 card6" >
                <h3 className="card-header bg-primary" style={{color:"white"}}>Admin Details</h3>
                <table className="table">
                       <tr>
                            <td>Name</td>
                            <td>{name}</td>    
                       </tr>
                       <tr>
                            <td>Email</td>
                            <td>{email}</td> 
                       </tr>
                       <tr>
                            <td>role</td>
                            <td> {role === 1 ? "Admin" : "Registered User"}</td> 
                       </tr>         

                </table>
            </div>
        );
    };

    return (
      
            <div className="row" style={{alignItems:"center",marginLeft:300}}>
                <div className="col-3">{adminLinks()}</div>
                <div className="col-9">{adminInfo()}</div>
            </div>
        
    );
};

export default AdminDashboard;
