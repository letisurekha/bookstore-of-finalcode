import React, { useState, useEffect } from "react";
import Layout from "../core/Layout";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";

import moment from "moment";

const Dashboard = () => {
    

    const {
        user: { _id, name, email, role }
    } = isAuthenticated();
    const token = isAuthenticated().token;

  
    const userLinks = () => {
        return (
            <div className="card">
              
                <ul className="list-group" style={{textAlign:"center"}}>
                    <li className="list-group-item">
                        <Link className="nav-link  btn btn-primary text:white" to="/cart">
                            My Cart
                        </Link>
                    </li>
                    <li className="list-group-item">
                        <Link className="nav-link  btn btn-primary text:white" to={`/profile/${_id}`}>
                            Update Profile
                        </Link>
                    </li>
                </ul>
            </div>
        );
    };

    const userInfo = () => {
        return (

            <div className="card mb-5 card6">
                <h3 className="card-header" style={{backgroundColor:"blue",color:"white"}}>User Details</h3>
                <table className="table">
                       <tr>
                            <td>Name</td>
                            <td>{name}</td>    
                       </tr>
                       <tr>
                            <td>Email</td>
                            <td>{email}</td> 
                       </tr>
                       <tr>
                            <td>role</td>
                            <td> {role === 1 ? "Admin" : "Registered User"}</td> 
                       </tr>         

                </table>
            </div>
        );
    };

  
    return (
        <div>
            <div className="row" style={{alignItems:"center",marginLeft:300}}>
                <div className="col-3">{userLinks()}</div>
                <div className="col-9">
                    {userInfo()}
                 
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
