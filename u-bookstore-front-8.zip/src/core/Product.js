import React, { useState, useEffect } from 'react';
import Layout from './Layout';
import { read, listRelated } from './apiCore';
import Card from './Card';
import ShowImage from './ShowImage';


const Product = props => {
    const [product, setProduct] = useState({});
 
    const [error, setError] = useState(false);

    const loadSingleProduct = productId => {
        read(productId).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    setError(data.error);
                } else {
                    setProduct(data);
                }
            }
        });
    };

    useEffect(() => {
        const productId = props.match.params.productId;
        loadSingleProduct(productId);
    }, [props]);

    return (
      
            <div className="row">
              
                <div className="col-4">
                    {product && product.description && <Card product={product} showViewProductButton={false}/>}
                </div>
                <div className="col-4">
                   
                </div>
                <div className="col-4">
               
                    <ShowImage item={product} url="product" className="card-img"/>
                </div>
            </div>
       
    );
};

export default Product;
