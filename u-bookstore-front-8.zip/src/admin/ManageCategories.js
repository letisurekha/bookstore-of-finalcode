import React, { useState, useEffect } from "react";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";
import { getCategories, deleteCategory } from "./apiAdmin";

const ManageCategories = () => {
    const [categories, setCategories] = useState([]);

    const { user, token } = isAuthenticated();

    const loadCategories = () => {
        getCategories().then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    setCategories(data);
                }
            }
        });
    };

    var x=0;

    const destroy = categoryId => {
        deleteCategory(categoryId, user._id, token).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    loadCategories();
                }
            }
        });
    };

    useEffect(() => {
        loadCategories();
    }, []);

    return (
        <div>
            <div className="row">
                <div className="col-12"><hr/>
                    <h2 className="text-center">
                        Total {categories.length} categories
                    </h2>
                </div>
            </div><br/>
            <div className="product-list">
                <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Action</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {categories && categories.category &&
                        categories.category.map((a,i) => (
                    <tr key={i}>
                        <td>{x=x+1}</td>
                        <td>{a.name}</td>
                        <td>
                               <Link to={`/admin/category/update/${a._id}`}>
                                    <span className="badge badge-warning badge-pill">
                                        Update
                                    </span>
                                </Link>
                        </td>
                        <td>        
                                <span
                                    style={{ cursor: "pointer", color: "#ffffff" }}
                                    onClick={() => destroy(a._id)}
                                    className="badge badge-danger badge-pill"
                                >
                                    Delete
                                </span>
                        </td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>    
        </div>
    );
};

export default ManageCategories;
