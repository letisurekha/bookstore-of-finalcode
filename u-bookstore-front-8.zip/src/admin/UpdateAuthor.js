
import React, { useState ,useEffect} from "react";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";
import {  getAuthor,updateAuthor  } from "./apiAdmin";

const UpdateAuthor = ({match}) => {
    
    const [name, setName] = useState("");
    const [error, setError] = useState(false);
    const [success, setSuccess] = useState(false);

   
    const { user, token } = isAuthenticated();



    
    const init = authorId => {
        getAuthor(authorId).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    setError({error: data.error});
                } else {
                   

                    setName({name:data.name});
                    console.log('name');
                    console.log(name);
                    console.log(data.name);
                }
            }
        });
    };

    

    useEffect(() => {
        init(match.params.authorId);
    }, []);


    const handleChange = e => {
        setError("");
        setName(e.target.value);
    };

    const clickSubmit = e => {
        e.preventDefault();
        setError("");
        setSuccess(false);
        updateAuthor(user._id, token, { name }).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    setError(data.error);
                } else {
                    setError("");
                    setSuccess(true);
                    setName(data.name)
                    console.log('name1');
                    console.log(name)
                }
            }
        });
    };

    const newAuthorFom = () => (
        <form onSubmit={clickSubmit}>
            <div className="form-group">
                <label className="text-muted">Name</label>
                <input
                    type="text"
                    className="form-control"
                    onChange={handleChange}
                    value={name}
                    autoFocus
                    required
                />
            </div>
            <button className="btn btn-outline-primary">Update Author</button>
        </form>
    );

    const showSuccess = () => {
        if (success) {
            return <h3 className="text-success">{name} is Updated</h3>;
        }
    };

    const showError = () => {
        if (error) {
            return <h3 className="text-danger">Author should be unique</h3>;
        }
    };

    const goBack = () => (
        <div className="mt-5">
            <Link to="/admin/dashboard" className="text-warning">
                Back to Dashboard
            </Link>
        </div>
    );

    return (
        <div>
            <div className="row">
                <div className="col-md-8 offset-md-2">
                    {showSuccess()}
                    {showError()}
                    {newAuthorFom()}
                    {goBack()}
                </div>
            </div>
        </div>
    );
};

export default UpdateAuthor;


















// import React, { useState, useEffect } from 'react';
// import { isAuthenticated } from '../auth';
// import { Link, Redirect } from 'react-router-dom';
// import { getAuthor, updateAuthor } from './apiAdmin';

// const UpdateAuthor = ({ match }) => {
//     const [values, setValues] = useState({
//         name: '',
//         loading: false,
//         error: false,
//         createdAuthor: '',
//         redirectToProfile: false,
//         formData: ''
//     });
//     const { user, token } = isAuthenticated();
//     const {
//         name,
//         loading,
//         error,
//         createdAuthor,
//         redirectToProfile,
//         formData
//     } = values;

//     const init = authorId => {
//         getAuthor(authorId).then(data => {
//             if(data !== undefined) {
//                 if (data.error) {
//                     setValues({ ...values, error: data.error });
//                 } else {
//                     setValues({
//                         ...values,
//                         name: data.name,
//                         formData: new FormData()
//                     });
//                 }
//             }
//         });
//     };


//     useEffect(() => {
//         init(match.params.authorId);
//     }, []);

//     const handleChange = name => event => {
//         formData.set(name);
//         setValues( ...values, [name]);
//     };

//     const clickSubmit = event => {
//         event.preventDefault();
//         setValues({ ...values, error: '', loading: true });

//         updateAuthor(match.params.authorId, user._id, token, formData).then(data => {
//             if(data !== undefined) {
//                 if (data.error) {
//                     setValues({ ...values, error: data.error });
//                 } else {
//                     setValues({
//                         ...values,
//                         name: '',
//                         loading: false,
//                         error: false,
//                         redirectToProfile: true,
//                         createdAuthor: data.name
//                     });
//                 }
//             }
//         });
//     };

//     const newPostForm = () => (
//         <form className="mb-3 card1" onSubmit={clickSubmit}>
//             <div className="form-group">
//                 <label className="text-muted">Name</label>
//                 <input onChange={handleChange('name')} type="text" className="form-control" value={name} />
//             </div>

           

//             <button className="btn btn-outline-primary">Update Author</button>
//         </form>
//     );

//     const showError = () => (
//         <div className="alert alert-danger" style={{ display: error ? '' : 'none' }}>
//             {error}
//         </div>
//     );

//     const showSuccess = () => (
//         <div className="alert alert-info" style={{ display: createdAuthor ? '' : 'none' }}>
//             <h2>{`${createdAuthor}`} is updated!</h2>
//         </div>
//     );

//     const showLoading = () =>
//         loading && (
//             <div className="alert alert-success">
//                 <h2>Loading...</h2>
//             </div>
//         );

//     const redirectUser = () => {
//         if (redirectToProfile) {
//             if (!error) {
//                 return <Redirect to="/" />;
//             }
//         }
//     };

//     return (
//         <div>
//             <div className="row">
//                 <div className="col-md-8 offset-md-2">
//                     {showLoading()}
//                     {showSuccess()}
//                     {showError()}
//                     {newPostForm()}
//                     {redirectUser()}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default UpdateAuthor;



