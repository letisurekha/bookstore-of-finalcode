import React, { useState, useEffect } from "react";
import { isAuthenticated } from "../auth";
import { Link } from "react-router-dom";
import { listOrders, getStatusValues, updateOrderStatus } from "./apiAdmin";

import moment from "moment";

const Orders = () => {
    const [orders, setOrders] = useState([]);
    const [statusValues, setStatusValues] = useState([]);

    const { user, token } = isAuthenticated();

    const loadOrders = () => {
        listOrders(user._id, token).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    setOrders(data);
                }
            }
        });
    };

    const loadStatusValues = () => {
        getStatusValues(user._id, token).then(data => {
            if(data !== undefined) {
                if (data.error) {
                    console.log(data.error);
                } else {
                    setStatusValues(data);
                }
            }
        });
    };

    useEffect(() => {
        loadOrders();
        loadStatusValues();
    }, []);

    const handleStatusChange = (e, orderId) => {
        updateOrderStatus(user._id, token, orderId, e.target.value).then(
            data => {
                if(data !== undefined) {
                    if (data.error) {
                        console.log("Status update failed");
                    } else {
                        loadOrders();
                    }
                }
            }
        );
    };
var x=0;
    const showStatus = o => (
        <div className="form-group">
            {/* <h3 className="mark mb-4">Status: {o.status}</h3> */}
            <select
                className="form-control"
                onChange={e => handleStatusChange(e, o._id)}
            >
                <option>Update Status</option>
                {statusValues.map((status, index) => (
                    <option key={index} value={status}>
                        {status}
                    </option>
                ))}
            </select>
        </div>
    );

    return (
       <div>
              <div className="row">
                <div className="col-md-8 offset-md-2">
                      <h3 style={{textAlign:"center",marginTop:10,marginBottom:10}}>Total Orders</h3>
                            <div className="product-list">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th>S.NO</th>
                                            <th>Orderedby</th>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Count</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                 {orders.map((o, oIndex) => (
                                    <tbody>
                                   
                                

                                        {o.products.map((p,i) => (
                                            <tr key={i}>
                                                    <td>{x=x+1}</td>
                                                    <td> {o.user.name}</td>
                                                    <td>{p.name}</td>
                                                    <td>₹{p.price}</td>
                                                    <td>{p.count}</td>
                                                    <td> {showStatus(o)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                               
                        
                            ))}
                    </table>
                </div>    
                          
                </div>
            </div>
       </div>
           
       
    );
};

export default Orders;
