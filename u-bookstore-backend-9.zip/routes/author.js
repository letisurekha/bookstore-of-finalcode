const express = require('express');
const router = express.Router();

const {requireSignin, isAuth, isAdmin} = require('../controllers/auth')
const { create, authorById, read,list}= require('../controllers/author');
const { userById }= require("../controllers/user");

router.post("/author/create/:userId",requireSignin, isAuth, isAdmin, create);
router.get("/author/:authorId",read)
router.get("/authors",list)


router.param('authorId', authorById)
router.param('userId', userById)

module.exports = router;