const express = require('express');
const Author = require('../models/authorModel');
const { isAuth, isAdmin } = require('../util');

const router = express.Router();


router.post('/author/create', isAuth, isAdmin, async (req, res) => {
    try{
        const author = new Author({
          name: req.body.name
        });
        const newAuthor = await author.save();
        if (newAuthor) {
          return res
            .status(201)
            .send({ message: 'New Author Created', data: newAuthor });
        }
        return res.status(500).send({ message: ' Error in Creating Author.' });
    
      }catch(error){
          res.send(error)
      }
        
    
  });
  

router.get('/author/:id', async (req, res) => {
  const author = await Author.findOne({ _id: req.params.id });
  if (author) {
    res.send(author);
  } else {
    res.status(404).send({ message: 'Author Not Found.' });
  }
});

router.get('/author', async (req, res) => {
 
    Author.find().exec((err, data) => {
    if (err) {
        return res.status(400).json({
            error: "author not found"
        });
    }
    res.json(data);
});
});

router.put('/:id', isAuth, isAdmin, async (req, res) => {
    const authorId = req.params.id;
    const author = await Author.findById(authorId);
    if (author) {
        author.name = req.body.name;
      const updatedAuthor= await author.save();
      if (updatedAuthor) {
        return res
          .status(200)
          .send({ message: 'Author Updated', data: updatedAuthor});
      }
    }
    return res.status(500).send({ message: ' Error in Updating Author.' });
});

router.delete('/:id', isAuth, isAdmin, async (req, res) => {
  const deletedAuthor = await Author.findById(req.params.id);
  if (deletedAuthor) {
    await deletedAuthor.remove();
    res.send({ message: 'Author Deleted' });
  } else {
    res.send('Error in Deletion.');
  }
});


router.get('/author', async (req, res) => {
    const author = req.query.author? { author: req.query.author } : {};
    const searchKeyword = req.query.searchKeyword
      ? {
          name: {
            $regex: req.query.searchKeyword,
            $options: 'i',
          },
        }
      : {};
    const sortOrder = req.query.sortOrder
      ? req.query.sortOrder === 'lowest'
        ? { price: 1 }
        : { price: -1 }
      : { _id: -1 };
    const authors = await Author.find({ ...author, ...searchKeyword }).sort(
      sortOrder
    );
    res.send(authors);
  });

module.exports= router;
