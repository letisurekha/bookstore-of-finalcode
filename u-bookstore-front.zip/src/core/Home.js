import React, { useState, useEffect, Fragment } from 'react';
import { getProducts } from './apiCore';
import Card from './Card';
import Search from './Search';
import Carousel from 're-carousel'





const Home = () => {
    
    const [productsByArrival, setProductsByArrival] = useState([]);
    const [error, setError] = useState(false);

    const loadProductsByArrival = () => {
        getProducts().then(data => {
            console.log(data);
            if(data !== undefined) {
                if (data.error) {
                    setError(data.error);
                } else {
                    setProductsByArrival(data);
                }
            }
        });
    };

    useEffect(() => {
        loadProductsByArrival();
     
    }, []);

    return (
        <div className="grid-container"> 
        <Carousel auto>
            <div style={{backgroundColor: 'tomato',width:'100%', height: '100%'}}>Frame 1</div>
            <div style={{backgroundColor: 'orange', height: '100%'}}>Frame 2</div>
            <div style={{backgroundColor: 'orchid', height: '100%'}}>Frame 3</div>
        </Carousel>

       
            <Search/>
              
                <div className="row mb-4">
                    {productsByArrival.map((product, i) => (
                        <div key={i} className="col-4 mb-3">
                            <Card product={product}/>
                        </div>
                    ))}
                </div>

                <footer className="footer">All right reserved.
                    <Fragment>
                            <a style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                href="https://www.facebook.com" class="fa fa-facebook"
                            ></a>
                            <a
                                style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                href="https://www.instagram.com" class="fa fa-instagram"
                            >
                            </a>
                    
                        <a
                                style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                href="https://www.twitter.com" class="fa fa-twitter"
                            >
                            </a>

                    </Fragment>
                </footer>
        </div>
    
    );
};

export default Home;
