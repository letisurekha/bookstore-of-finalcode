import React, { useState } from 'react';
import { Link } from 'react-router-dom';


const Contact = ({history}) => {
   
    const clickSubmit = event => {
        event.preventDefault();

        history.push('/response');
    };
    const contactForm = () => (
        <div>
            <div className="row">
            <div className="col-1">
                </div>
                <div className="col-5">
                <h4 className="mb-3" style={{color:"black",textAlign:"center",fontFamily:"revert"}}><b><i className="fas fa-book-open">UNICORN</i></b></h4><hr/>
                        <h4 className="mb-3" style={{color:"black",textAlign:"center"}}>Contact us</h4>
                        <p className="text-center"><i className="fas fa-home"/>  : Plat-No: 4-128,Banglore</p>
                        <p className="text-center"><i className="fas fa-envelope"/> : <a href="https://www.gmail.com">unicornbooks@gmail.com</a></p>
                        <p className="text-center"><i className="fas fa-phone"/>  :   +91 7789436786</p>
                        <p className="text-center">We are really very happy to  you. </p>
                        <p className="text-center">Please contact us for further any queries. </p>
                </div>
              
                <div className="col">
                <form className="card7">
                        <h4 className="mb-3" style={{color:"black",textAlign:"center",fontFamily:"revert"}}><b><i className="fas fa-book-open">Get in touch</i></b></h4><hr/>
                        <p className="mb-3" style={{color:"black",textAlign:"center"}}>Please fill out the quick form and we will be in touch with lightening speed</p>
                        <div className="form-group">
                            <label className="text-muted">Name</label>
                            <input type="text" className="form-control" required/>
                        </div>

                        <div className="form-group">
                            <label className="text-muted">Email</label>
                            <input type="email" className="form-control"
                                    message= "invalid email address"required/>
                        </div>

                        <div className="form-group">
                            <label className="text-muted">Mobile Number</label>
                            <input type="text" className="form-control" values="+91" required/>
                        </div>
                        <div className="form-group">
                            <label className="text-muted">Message</label>
                            <textarea className="form-control" placeholder="Message" required/>
                        </div>
                    <button className="btn btn-outline-primary" onClick={clickSubmit} style={{borderRadius:5}}>Submit</button>    
                </form>

                </div>
            </div>
             
        </div>
      
    );

    return (
        <div>
           {contactForm()}
        </div>
    );
};

export default Contact;
